package com.example.caesarscypher;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;
import java.util.Timer;

public class GameActivity extends AppCompatActivity {

    private EditText cipher_editText;
    private EditText plain_editText;
    private TextView key_textView;
    private TextView timer_textView;
    private TextView strikes_textView;
    private TextView currentScore_textView;
    private String strikes = "";
    private int strikeCount = 0;
    private GameDBHandler GameDBHandler;
    private CountDownTimer timer;
    private int score = 0;
    private String currentPTFromDB = "";
    private int currentKey = 0;

    private static final String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    // plain texts
    private static final String[] plaintext = {
            "FIGHT",
            "RUN",
            "HELP",
            "FLANK",
            "DEFEND",
            "FALLBACK",
            "COMMAND",
            "CAPTURE",
            "RETREAT",
            "PUSH",
            "LOOK",
            "REGROUP",
            "WEST",
            "NORTH",
            "EAST",
            "BARBARIANS",
            "ROME",
            "ATTACK",
            "HOLD",
            "REBEL",
            "GO"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        cipher_editText = findViewById(R.id.cipher_editText);
        plain_editText = findViewById(R.id.plain_editText);
        key_textView = findViewById(R.id.key_textView);
        strikes_textView = findViewById(R.id.strikes_textView);
        currentScore_textView = findViewById(R.id.currentScore_textView);

        GameDBHandler = new GameDBHandler(GameActivity.this);

        // start the game
        playGame();
    }

    // main game method
    private void playGame() {
        // get new plain text cover to cipher text with current key
        int key = getKey();
        //String PT = getRandomPlainText();
        currentPTFromDB = getRandomPlainText();
        String CT = encryptPlainText(currentPTFromDB,key);

        // display new CT (cipher text) and key
        //cipher_editText.setText(CT + "\n" + currentPTFromDB); // display plain text for testing
        cipher_editText.setText(CT);
        key_textView.setText("Key: " + key);

        //start timer (5 minutes)
        startTimer(500);

    }

    // user input decipher
    public void decipher(View view) {

        String PT = plain_editText.getText().toString();

        // make sure all data is entered
        if (isEmpty(plain_editText)) {
            Toast.makeText(GameActivity.this, "ERROR Missing Fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // convert data to all caps  also with no spaces??
        PT.toUpperCase();

        //check if it is correct
        if(PT.equals(currentPTFromDB)){

            //Toast.makeText(GameActivity.this, "CORRECT +100 POINTS", Toast.LENGTH_SHORT).show();
            // add to score
            score += 100;
            currentScore_textView.setText("Score: " + score);

            //restart game for another round
            playGame();
        } else { // if incorrect add a strike and restart the game
            //Toast.makeText(GameActivity.this, "Time Expired!", Toast.LENGTH_SHORT).show();
            strike();
            playGame();
        }

    }

    private boolean isEmpty(EditText etText) {
        return etText.getText().toString().trim().length() == 0;
    }

    // quit the game button handler
    public void quit(View view) {
        gameOver();
    }
    // this method handles the end of the game plus final score tally
    private void gameOver() {
        //end the timer
        stopCount();

        // add final score
        GameDBHandler.addNewScore("" + score);

        // go to score page
        Intent intent = new Intent(this, ScoreActivity.class);
        intent.putExtra("finalScore", "" + score);
        startActivity(intent);
    }

    // add a strike if time goes out or decipher is wrong... 3 strikes you're out!
    private void strike() {
        strikes = strikes + "X"; // add a strike
        strikeCount += 1; // add another strike to total

        // display the strikes
        strikes_textView.setText(strikes);

        // if 3 strikes you're out!
        if(strikeCount == 3) {
            gameOver();
        }
    }

    // timer method
    private void startTimer(long time) {
        long timeToCountDown = time * 1000;
        timer_textView = findViewById(R.id.timer_textView);

        timer = new CountDownTimer(timeToCountDown, 1000) {

            @Override
            public void onTick(long timeToCountDown) {
                timer_textView.setText("" + timeToCountDown / 1000);
            }

            @Override
            public void onFinish() {
                timer_textView.setText("0");
                // round or potentially game over
                strike();
                playGame();
            }
        }.start();
    }

    // stop count down method
    private void stopCount() {
        timer.cancel();
    }

    //generate new key (plus 1 every round?? for now just random between 1-10)
    private int getKey() {

        Random rand = new Random();

        int upperbound = 10;

        int random_key = rand.nextInt(upperbound) + 1;

        return random_key;
    }

    // encrypt the plain text for the user to decipher
    public String encryptPlainText(String PT, int key){

        // encrypt with caesar cipher with current key
        // remove or ignore spaces (split string)
        String CT = "";

        for (int i = 0; i < PT.length(); i++) {
            int charPosition = alphabet.indexOf(PT.charAt(i));
            int keyVal = (key + charPosition) % 26;
            char replaceVal = alphabet.charAt(keyVal);
            CT += replaceVal;
        }

        return CT;

        // for testing just skip encrypt for now
        //return PT;
    }

    // returns random plain text
    public String getRandomPlainText() {

        Random rand = new Random();

        int upperbound = plaintext.length;

        int random_index = rand.nextInt(upperbound);

        return plaintext[random_index];
    }
}