package com.example.caesarscypher;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Random;

public class GameDBHandler extends SQLiteOpenHelper {

    public String currentUser = "";
    private static final String DB_NAME = "gameDB";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAME = "gameData",ID_COL = "id",
            SCORE_COL = "score";

    public GameDBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        // create table
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + SCORE_COL + " TEXT)";

        db.execSQL(query);
    }

    // add plain texts
    public void addNewScore(String score) {

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();

        values.put(SCORE_COL, score);

        db.insert(TABLE_NAME, null, values);

        db.close();
    }

    public Cursor getScores() {

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM gameData;", new String[] {});
        if (cursor.getCount() > 0) return cursor;
        else
            return null;

    }

//    public boolean authenticateUser(String username, String password) {
//
//        SQLiteDatabase db = this.getWritableDatabase();
//        Cursor cursor = db.rawQuery("SELECT * FROM USERS WHERE username = ? AND password = ?", new String[] {username, password});
//        if (cursor.getCount() > 0) return true;
//        else
//            return false;
//
//    }
//
//    public String getCurrentUser() {
//        return currentUser;
//    }
//
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
