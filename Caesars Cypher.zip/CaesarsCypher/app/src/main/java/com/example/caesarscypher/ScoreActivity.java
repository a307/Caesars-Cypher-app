package com.example.caesarscypher;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ScoreActivity extends AppCompatActivity {

    private TextView score_textView;
    private GameDBHandler GameDBHandler;

    //Bundle extras;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        score_textView = findViewById(R.id.score_textView);
        GameDBHandler = new GameDBHandler(ScoreActivity.this);
        //extras = getIntent().getExtras();
        // get final score from game
        String finalScore = getIntent().getStringExtra("finalScore");

        Cursor result = GameDBHandler.getScores();
        if (result == null) {
            Toast.makeText(ScoreActivity.this, "No score data", Toast.LENGTH_SHORT).show();
            return;
        }
        StringBuffer buffer = new StringBuffer();
        while (result.moveToNext()) {
            //buffer.append("Id: " + result.getString(0) + "\n");
            buffer.append(result.getString(1) + "\n");
        }

        // display final score as well as all high scores??
        score_textView.setText("FINAL SCORE.........." + finalScore + "\n" +
                "\nHigh Scores\n\n" + buffer);

    }

    // return to main menu
    public void Leave(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}